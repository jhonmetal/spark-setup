import os
import subprocess
from delta import configure_spark_with_delta_pip
from pyspark.sql import SparkSession

def setup_spark(app_name="DefaultApp"):
    subprocess.run(["apt-get", "update"], check=True)
    subprocess.run(
        ["apt-get", "install", "-qq", "openjdk-8-jdk-headless"],
        stdout=subprocess.DEVNULL,
        check=True,
    )
    subprocess.run(["pip", "install", "delta-spark==3.3.2"], check=True)

    os.environ["JAVA_HOME"] = "/usr/lib/jvm/java-8-openjdk-amd64"
    os.environ["SPARK_HOME"] = "/usr/local/lib/python3.11/dist-packages/pyspark"

    builder = (
        SparkSession.builder
        .appName(app_name)
        .config("spark.sql.warehouse.dir", "SparkWarehouse")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .enableHiveSupport()
    )
    return configure_spark_with_delta_pip(builder).getOrCreate()